/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kisanapp;

/**
 *
 * @author rhars
 */
public class Kisanapp {

    public static void main(String[] args) {
       
        
    }
}
